#!python3

# Queremos executar esse programa com o argumento de uma liha de comando correspondente ao nome da conta
#por exemplo, email ou blog.
# A senha dessa conta será copiada para o clipboard para que o usuário possa colá-la em um campo de senha.
# Dessa maneira o usuário poderá ter senhas longas e complexas sem a necessidade de memorizá-las

#pw.py - Um programa para repositório de senhas que não é seguro

# Dicionário com nomes de onde devera usar senha e sua respectiva senha
PASSWORDS = {'email':'F7minBDDuvMJuxESSKHFhTxFtjVB6',
             'blog':'VmALvQyKAxiVH5G8v01ifmLZF3sdt',
             'luggage':'12345'}

import sys
if len(sys.argv) < 2:
    print('Usage: python pw.py [account] - copy account password ')
    sys.exit()
    
account = sys.argv[1] # o primeiro argumento da linha dee comando é o nome da conta
 
 
if account in PASSWORDS:
     pyperclip.copy(PASSWORDS[account])
     print('password for' +account+ 'copied to clipboard.')
else:
     print('There is no account named' +account)   