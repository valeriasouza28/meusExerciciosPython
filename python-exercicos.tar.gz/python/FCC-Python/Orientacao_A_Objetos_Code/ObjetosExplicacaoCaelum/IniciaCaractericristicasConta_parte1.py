#Vamos criar uma conta em um banco com as seguintes caracteristicas:
numero1 = '123-4'
titular1 = 'João'
saldo11 = 120.0
limite1 = 1000.0

#Mas temos que criar uma segunda conta. Então, criamos mais uma:
numero2 = '123-5'
titlar2 = 'José'
saldo2 = 200.0
limite2 = 1000.0

#Mas a medida que o banco cresce dessa maneira seria muito mais trabalhoso dar manutenção.
#Criar um dicionario para agrupar as caracteristicas e dados de uma  conta especifica:
conta = {"numero"  : '123-4', "titular" : "José", "saldo" : 120.0, "limite" : 1000.0}
#print(conta["numero"])
#print(conta["titular"])

# Agora vamos criar uma segunda conta, crie outro dicionário:
conta2 = {"numero" : '123-5', "titular" : "José", "saldo" : 120.0, "limite" : 1000.0}

#Mesmo agrupando os dados terremos que repetir o código para criar uma nova conta.
#Vamos criar uma função responsável para criar uma conta:
def cria_conta():
    conta = {"numero": '123-4', "titular": "João", "saldo": 120.0, "limite": 1000.0}
    return conta

#Ainda não é o ideal para criar várias contas. Vamos receber esses valores como parâmetros de uma função e retornamos a conta:
def cria_conta(numero, titular, saldo, limite):
    conta ={"numero": numero, "titular": titular, "saldo": saldo, "limite": limite }
    return conta

#Desta maneira é posível criar várias contas com dados diferentes:
conta1 = cria_conta('123-4', 'João', 120.0, 1000.0)
conta2 = cria_conta('123-5', 'José', 200.0, 1000.0)

#Para acessar o número de cada uma delas, fazemos:

print(conta1['numero'])
print(conta2['numero'])