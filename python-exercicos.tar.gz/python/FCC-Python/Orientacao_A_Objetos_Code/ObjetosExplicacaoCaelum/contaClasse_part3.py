class Conta:
    
  def __init__(self, numero, titular, saldo, limite):
    self.numero = numero
    self.titular = titular
    self.saldo = saldo
    self.limite = limite

    # Se executarmos com conta = Conta() o código retornaria um erro.
# A classe Conta gora nos obriga a passar os atributos para criar uma conta:

#Para manipular o objeto conta e e acessarmos os atributos, utilizamos o operador "."
#print(conta.titular)
#print(conta.saldo)

  def deposita(self, valor):
    self.saldo += valor

  def saca(self, valor):
    self.saldo -= valor

  def extrato(self):
    print("numero: {} \nsaldo: {}".format(self.numero,self.saldo))

conta = Conta('123-4', 'João', 120.0, 1000.0)
conta.deposita(20.0)
conta.extrato()
conta.saca(15)
conta.extrato()


#importar de outro arquivo
#from contaClasse_part3 import Conta
#conta = Conta()
#print(type(conta))
#<class '__main__.Conta'>

# Podemos modificar esse objeto conta em tempo de execução. Por exemplo, podemos acrscentar atributos a ele:
#conta.titular = "João"
#print(conta.titular)

#conta.saldo = 120.0
#print(conta.saldo)