#Ainda não é o ideal para criar várias contas. Vamos receber esses valores como parâmetros de uma função e retornamos a conta:
def cria_conta(numero, titular, saldo, limite):
    conta ={"numero": numero, "titular": titular, "saldo": saldo, "limite": limite }
    return conta

#Anteriormente criamos uma conta.
#Agora vamos criar uma função para representar a funciomalidade depositar. Além do valor a ser depositado, preciasmos saber qual conta receberá este valor:
def deposita(conta, valor):
    conta['saldo'] = conta['saldo'] + valor
    
#O Python permite  escrvera mesma coisa de uma maneira mais elegante utilizando '+=':
def deposita(conta, valor):
    conta['saldo'] += valor
    
#Podemos fazer algo semelhante com saca():
def saca(conta, valor):
    conta['saldo'] -= valor
    
#Vamos criar outra que mostra o extrato da conta:
def extrato(conta):
    print("numero: {} \nsaldo:{}".format(conta['numero'], conta['saldo']))
    
#Agora podemos testar o código supondo que esteja dentro de um mesmos arquivo:
conta = cria_conta('123-4', 'João', 120.0, 1000.0)
deposita(conta, 15.0)
extrato(conta)
saca(conta, 20.0)
extrato(conta)