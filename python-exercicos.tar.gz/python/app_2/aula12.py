import requests

# vamos aprender a instalar pacotes usando o pip instalador de pacotes do python
# para saber a versão do pip instalada, digite no terminal: pip --version
# A primeira biblioteca a ser instalada será a a requests digite no terminal: pip install requests
import requests

response = requests.get('https://viacep.com.br/ws/{}/json/'.format('04094000'))
print(response.status_code)