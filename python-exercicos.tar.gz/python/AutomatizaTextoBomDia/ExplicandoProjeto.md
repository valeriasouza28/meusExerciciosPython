# Automate Good Mornings Text with Python 
# Automatizando messsagens de texto de bom dia com python 

       O objetivo desse projeto é enviar mensagem de texto para para alguém todas as manhãs, isso pode parecer um pouco complicado, mas se quebrá-lo em pequenas etapas, isso tornará mais fécilcodificar este projeto, então o que vamos fazer é dividir em pequenas etapas e descobrir o que realmente escrever como o código é fazendo algo chamado escrever pseudocódigo.

       O pseudocode é como criar um esboço antes de escrever um artigo,um esboço do que planeja codificar quando estiver a escrever seu pseudocódigo você poderá pensar em como o fará manualmente no primeiro passo é que você tem que  pensar nas mensagens de texto que deseja enviar para que este seja o primeiro passo podemos ter uma coleção de mensagens pré-definidas que podemos enviar.

       O segundo,é realmente enviar a mensagem, para enviar a mensagem podemos usar uma api que nos permite enviar mensagem de texto para alguém.

       O terceiro passo é na verdade agendar as mensagens, por exemplo á seis  da manhã. Tem um conjunto usando uma biblioteca python que permite agendar texto em um horário especifico.
        
       Então agora que dividimos esse objetivo maior em etapas menores, mai fácil escrever algum código.

       Começando com a etapa um,estamos decidindo salvar todas as nossas mensgens pré-criadas em strings e esssas strings podem ser slavals em array, vamos chamar essa array de ciatações de bom dia,então vamos em frente escrever alguns, porque se enviamos a mesma mensagem todo dia.

       vamos para o segundo passo! O segundo passo é trabalhar com uma API para enviar mensagens pré-defindas via texto, para não precisarmos reiventar a muita programação é ver o que já existe e incorpor-lo no que você tem podemos usar o twilio que nos permite enviar mensagens de texto e é um ser viço gratuito, o melhor da twilio é que está muito bem documentado, por isso essa tarefa que temos de enviar uma mensagem de texto esta na verdade diretamente no documento, assim se vocẽ olhar para a documentação poderá ver exatamente o que precisaremos fornecer aos  nossos clientes twillio para enviar mensagens para um número de telefone especifico.

       importe:

       import twlio.rest import Client

       Então vamos criar uma função chamada send(enviar) que será responsável  receber uma mensagem e depois enviar essa mensagem para um número de telefone especifico, então vamos adicionar o número da conta que vou deixar em um branco, mas o que você vai fazer é preencher isso com o número da sua conta 