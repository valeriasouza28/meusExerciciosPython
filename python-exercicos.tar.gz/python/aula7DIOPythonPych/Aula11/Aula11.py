#  Gerenciando e criando exceções costomizadas com try, except, else e finnaly

lista = [1, 10]

# vamos criar um erro
# tudo que stiver no try vai cair para o tratamento de exceção
#E vamos fazer uma exceção de ZeroDivisioError, que nada mais é do que uma classe de exceções
try:
    arquivo = open('/home/oem/PycharmProjects/aula7DIOPythonPych//Aula9/teste.txt', 'r')
    texto = arquivo.read()
    divisao = 10 / 1
    numero = lista[1]



 # As exceções funcionam como uma árvore sendo a BaseException no topo hierarquia das exceções

except ZeroDivisionError:
    print('Não é possível realizar divisão por zero')
except ArithmeticError:
    print('Houve um erro ao realizar uma operação aritmétca')
except IndexError:
    print('Erro ao acessar um índice inválido da lista')
except Exception as ex:
    print('erro desconhecido. Erro:{}'.format(ex))
else:
    print('Executa quando não ocorre exceção')
#Ttudo que está no finally dando erro ou não ele vai ser executado
finally:
    print('Sempre executa')
    print('fechando arquivo')
    arquivo.close()