# vamos transformar essas funções em uma classe


# para transformar isso em uma classe utilizamos a palavra 'class'
class Calculadora:
    # perceba que o nome da classe começa com letras maiúsculas

    # dentro da classe consiguimos inicializar valores dentro daquela classe usando "def __init__ (self,)"

    # como init não pode ser vazio vamos colocar aqui o pass
    # o pass ele não faz nada apenas para não deixar o init vazio

    # usamos init  sempre que formos instanciar a classe calculadora
    # self referencia o próprio objeto
    # E a e b são parâmetros

    # tiramos o self do return e mantemos no return o valor_a, valor_b
    def soma(self, valor_a, valor_b):
        return valor_a + valor_b

    def subtracao(self, valor_a, valor_b):
        return valor_a - valor_b

    def multiplicao(self, valor_a, valor_b):
        return valor_a * valor_b

    def divisao(self, valor_a, valor_b):
        return valor_a / valor_b


# para fazer a indentação seleciona a parte a ser selecionada e apertar tab


# vamos intanciar uma classe
# aqui na calculadora não passamos valor nenhum

# este trecho de código do if é utilizado para
# não utilizar determinado trecho de código sem ser necessário exclui-lo

if __name__ == '__main__':
    calculadora = Calculadora()
    # e para fazer cálculos entre os números informamos os valores
    # como por exemplo a soma de 10 e 2
    print(calculadora.soma(10, 2))

    print(calculadora.subtracao(5, 3))

    print(calculadora.divisao(100, 2))
    print(calculadora.multiplicao(10, 5))
